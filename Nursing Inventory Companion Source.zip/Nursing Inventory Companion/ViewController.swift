//
//  ViewController.swift
//  Nursing Inventory Companion
//
//  Created by Lucas Miller on 1/21/20.
//  Copyright © 2020 Lucas Miller. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}
